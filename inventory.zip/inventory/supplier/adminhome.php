<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>

<frameset cols="25%,*">
	<frame src="links.php" name="left" noresize="yes">
	<frame src="home.php" name="right" noresize="yes">
</frameset>



</html>