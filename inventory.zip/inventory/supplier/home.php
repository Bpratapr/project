<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<center><h1>WELCOME</h1></center>
<form method="post" align="center">
<input type="submit" name="getdetails" value="GET DETAILS" />
</form>
</body>
</html>
<?php 

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());
}
if(isset($_POST['getdetails']))
{

$sql="select * from orders ";
$result=mysqli_query($conn,$sql);
?>
<table border="2" cellspacing="0" cellpadding="10" align="center">
   <tr>
      <th>ORDER ID</th>
      <th>CUSTOMER NAME</th>
      <th>BRAND TYPE</th>
      <th>QUANTITY</th>
      <th>TOTAL PRICE</th>
      <th>DOP</th>
      <th>ADDRESS</th>
      <th>PHONE</th>
    </tr>
 <?php
while($array=mysqli_fetch_assoc($result)) 
							{ 
echo "<tr>";	
echo "<td>".$array['id']."</td>";
echo "<td>".$array['name']."</td>";
echo "<td>".$array['brand']."</td>";
echo "<td>".$array['quantity']."</td>";
echo "<td>".$array['totalprice']."</td>";
echo "<td>".$array['dop']."</td>";
echo "<td>".$array['address']."</td>";
echo "<td>".$array['phone']."</td>";
echo "</tr>";        

} 

}
 
?>
