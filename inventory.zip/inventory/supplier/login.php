<?php include('lvalid.php'); ?>
<html>
<head>
<title>Supplier Login</title>
<style type="text/css">
body{
background-image:url(bg1.jpg);
background-size:cover;
}

form {
  background: rgba(19, 35, 47, 0.9); 
  padding: 40px;
  max-width: 600px;
  margin: 40px auto;
  border-radius: 10px;
  box-shadow: 0 4px 10px 4px rgba(19, 35, 47, 0.3);
}

.aa input[type="text"]{
width: 200px;
height:35px;border:0;
border-radius:5px;

padding-left:15px;
}
.aa input[type="password"]{
width: 200px;
height:35px;border:0;
border-radius:5px;

padding-left:15px;
}
.aa input[type="submit"]{
width:100px;
height:35px;
border:0;
border-radius:5px;

background-color: skyblue;
font-weight: bolder;
}

.aa input[type="submit"]:hover
{
	cursor: pointer;
}


a{
	text-decoration: none;
	color: white;
}
a:hover
{
	text-decoration: underline;
	color:red;
}
marquee
{
	color:white;
}
marquee:hover
{
	color:red;
	background: yellow;
	padding: 5px;
}

</style>
</head>
<body>
<br><br><br><br>
<div class="aa">

<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" align="center">
	<h1 style="color: white;">SUPPLIER LOGIN</h1>
	
<input type="text" id="user" name="user" placeholder="Enter username" value="<?php echo $username; ?>" autofocus><br><br>
<input type="password" name="pass" placeholder="Enter password"><br><br>
<input type="submit" name="login" placeholder="Login" value="LOGIN" /><br><br>



</form>
</div>
</body>
</html>