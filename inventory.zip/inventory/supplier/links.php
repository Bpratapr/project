<?php 

session_start();

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());
}

$sup=$_SESSION['user'];

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		
		.l 
		{
			background-color: grey;
			max-height: 600px;
		}	
		
		a
		{
			text-decoration: none;
			display: block;
			padding: 10px;
			background-color: grey;
			color: white;
		}
		a:hover
		{
			background-color: black;
		}

		h3
		{
			color:yellow;
			text-decoration: underline;
		}

	</style>
</head>
<body>
	<div class="l"><br><br>
		<h3>WELCOME <?php $s1=strtoupper($sup); echo $s1;  ?></h3>
	<a href="update.php" target="right">UPDATE INVENTORY</a>
	
<a href="logout.php" target="_top">LOGOUT</a>
</div>
</body>
</html>