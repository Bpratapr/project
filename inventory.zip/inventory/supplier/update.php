

<?php 


session_start();
$conn = new mysqli('localhost', 'root', '', 'inventory') 
or die ('Cannot connect to db');
$result2 = $conn->query("select brand from watches");
$result3 = $conn->query("select brand,quantity from watches");
$result4 = $conn->query("select brand,quantity from watches");

if(isset($_POST['update']))
{
	$brand=$_POST['bnd'];
	$result5 = $conn->query("select quantity from watches where brand='$brand'");
	$q=mysqli_fetch_assoc($result5);
	$presentquantity=$q['quantity'];
	
	$quantity=$_POST['quantity'];
	$total=$presentquantity+$quantity;
	$sql="update watches set quantity=$total where brand='$brand' ";
	$quantity=0;
	if(mysqli_query($conn,$sql))
	{
		echo "<script> alert('UPDATED SUCCESSFULLY'); </script>";
		
		
	}
}


if(isset($_POST['present']))
{

echo "BRAND"." "."QUANTITY"."<br>";
while ($roow=mysqli_fetch_assoc($result4)) {
	# code...
	echo $roow['brand']." ".$roow['quantity']."<br>";
}

}





 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		#b
		{
			width: 250px;
			height: 35px;
		}
		#b2
		{
			width: 250px;
			height: 30px;
		}
	</style>
</head>
<body>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" align="center">
	<br><br><br>
	
<table align="center">
	<tr><td>Product</td>

		<td>
	<?php  
echo "<select name='bnd' id='b'>";
echo '<option value="'."none".'">'."--select--".'</option>';

while ($row = $result2->fetch_assoc()) 
{

unset($btype);
$btype = $row['brand'];
echo '<option value="'.$btype.'">'.$btype.'</option>';
                 
}
echo "</select>";  

?>

	</tr>
	<tr><td>quantity</td><td><input type="text" name="quantity" placeholder="Enter quantity" id="b2"></td></tr>
	<tr><td colspan="2"><input type="submit" name="update" value="UPDATE"></td></tr>
	<tr><td colspan="2"><input type="submit" name="present" value="PRESENT DETAILS"></td></tr>
</table>

</form>
</body>
</html>
<?php 

$conn = new mysqli('localhost', 'root', '', 'inventory') 
or die ('Cannot connect to db');


 ?>