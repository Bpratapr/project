<?php 

session_start();

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());
}
 ?>


<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		.l 
		{
			background-color: grey;
			max-height: 600px;
		}	
		
		a
		{
			text-decoration: none;
			display: block;
			padding: 10px;
			background-color: grey;
			color: white;
		}
		a:hover
		{
			background-color: black;
		}

		h3
		{
			color:yellow;
			text-decoration: underline;
		}
		h2
		{
			color: yellow;
		}
	</style>
</head>
<body>
	
	<div class="l">
		<h2>WELCOME <?php $name=strtoupper($_SESSION['user']); echo $name; ?> </h2>
	<a href="details.php" target="right">DETAILS BY DATE</a>
	
	
<a href="logout.php" target="_top">LOGOUT</a>
</div>
</body>
</html>