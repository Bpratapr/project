<?php 

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());


}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body><br><br><br>
  <h2 align="center">SEARCH FOR ORDERS</h2>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" align="center">
	
<table align="center">
	<tr><td>ENTER ORDER ID</td><td><input type="text" name="id" placeholder="ENTER BILL NO
    "></td></tr>
	
	<tr><td colspan="2"><input type="submit" name="getdetails" value="GET DETAILS"></td></tr>
</table>

</form>
</body>
</html>
<?php 

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());
}
if(isset($_POST['getdetails']))
{

$orderid=$_POST['id'];

$sql="select * from orders where id=$orderid ";
$result=mysqli_query($conn,$sql);
?>
<table border="2" cellspacing="0" cellpadding="10" align="center">
   <tr>
      <th>BILL NO</th>
      <th>CUSTOMER NAME</th>
      <th>BRAND TYPE</th>
      <th>QUANTITY</th>
      <th>TOTAL PRICE</th>
      <th>DOP</th>
      <th>ADDRESS</th>
      <th>PHONE</th>
    </tr>
 <?php
while($array=mysqli_fetch_assoc($result)) 
							{ 
echo "<tr>";	
echo "<td>".$array['id']."</td>";
echo "<td>".$array['name']."</td>";
echo "<td>".$array['brand']."</td>";
echo "<td>".$array['quantity']."</td>";
echo "<td>".$array['totalprice']."</td>";
echo "<td>".$array['dop']."</td>";
echo "<td>".$array['address']."</td>";
echo "<td>".$array['phone']."</td>";
echo "</tr>";        

} 

}
 
?>
