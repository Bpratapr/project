<!DOCTYPE html>
<html>
<head>
	<title>ADMIN HOME</title>
</head>

<frameset cols="25%,*">
	<frame src="links.php" name="left">
	<frame src="odetails.php" name="right">
</frameset>



</html>