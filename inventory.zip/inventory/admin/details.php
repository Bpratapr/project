<?php 

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());


}

 ?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body><br><br><br>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" align="center">
	
<table align="center">
	<tr><td>FROM DATE</td><td><input type="date" name="fromdt"></td></tr>
	<tr><td>TO DATE</td><td><input type="date" name="todt"></td></tr>
	<tr><td><input type="submit" name="getdetails" value="GET DETAILS"></td></tr>
</table>

</form>
</body>
</html>
<?php 

$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());
}
if(isset($_POST['getdetails']))
{

$fdate=$_POST['fromdt'];
$tdate=$_POST['todt'];
$sql="select * from orders where dop between '$fdate' and '$tdate' ";
$result=mysqli_query($conn,$sql);
?>
<table border="2" cellspacing="0" cellpadding="10" align="center">
   <tr>
      <th>ORDER ID</th>
      <th>CUSTOMER NAME</th>
      <th>BRAND TYPE</th>
      <th>QUANTITY</th>
      <th>TOTAL PRICE</th>
      <th>DOP</th>
      <th>ADDRESS</th>
      <th>PHONE</th>
    </tr>
 <?php
while($array=mysqli_fetch_assoc($result)) 
							{ 
echo "<tr>";	
echo "<td>".$array['id']."</td>";
echo "<td>".$array['name']."</td>";
echo "<td>".$array['brand']."</td>";
echo "<td>".$array['quantity']."</td>";
echo "<td>".$array['totalprice']."</td>";
echo "<td>".$array['dop']."</td>";
echo "<td>".$array['address']."</td>";
echo "<td>".$array['phone']."</td>";
echo "</tr>";        

} 

}
 
?>
