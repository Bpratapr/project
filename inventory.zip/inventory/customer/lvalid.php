
<?php 


session_start();
$username="";
$pass="";
$error=array();
// create connection
/*
if(isset($_SESSION['user']))
{
	echo "<script> alert('user has active session'); </script>";
	header('location:home.php');
}
*/
$conn=mysqli_connect("localhost","root","","inventory");
if (!$conn) {
	die("error in".mysqli_connect_error());
}

//
if(isset($_POST['login']))
{
	$username=$_POST['user'];
	$pass=$_POST['pass'];

if(empty($username)&&empty($pass))
{
	echo "<script>alert('Please enter username and password')</script>";
}

else if(empty($username))
{
	echo "<script>alert('Please enter username')</script>";
}
else if(empty($pass))
{
	echo "<script>alert('Please enter password')</script>";
}
else{

	
$sql="select name,password from customer where name= '$username' and password='$pass'";
$result=mysqli_query($conn,$sql);
$row = mysqli_fetch_array($result);

if($row['name'] == $username && $row['password'] == $pass)
{
	$_SESSION['user']=$username;
	$_SESSION['pass']=$pass;
	header('location: home.php'); // redirect to the home page
}

else
	echo "<script> alert('Please check username and password'); </script>";

 }
}

if(isset($_POST['register']))
{
	$name=$_POST['user'];
	$email=$_POST['email'];
	$mobile=$_POST['phone'];
	$pass=$_POST['pass'];
	$sql="insert into customer(name,email,phone,password) values('$name','$email',$mobile,'$pass') ";
	if(mysqli_query($conn,$sql))
	{
		echo "<script> alert('REGISTERED SUCCESSFULLY'); </script>";
		header("location: login.php");

	}
	else
		echo "<script> alert('FAILED TO REGISTER'); </script>";

}


mysqli_close($conn);
 ?>