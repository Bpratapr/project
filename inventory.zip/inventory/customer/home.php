
<?php
session_start();
if(!isset($_SESSION['user']))
{
	
	header('location:login.php');
}
$conn = new mysqli('localhost', 'root', '', 'inventory') 
or die ('Cannot connect to db');

    $result1 = $conn->query("select id from watches");
    $result2 = $conn->query("select brand from watches");
    $result3 = $conn->query("select quantity from watches");

 ?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style type="text/css">
		
		td
		{
			text-align: left;
		}

		body
		{
			background-image: url('w2.jpg');
			background-size: cover;

		}
.book
{
	background-color: white;
	color:black;
	margin:0 auto;
	border:5px;
	max-width: 500px;
	padding-bottom: 40px;
	border-radius: 15px;
	box-shadow: 10px 15px 15px #5c5e60;
	font-weight: bolder;
	opacity: 0.8;
}
.book form [type="text"],.book form [type="date"],.book form [type="email"]
{
	width: 180px;
	height: 25px;
	padding-left: 5px;
	font-weight: bold;
	font-style:italic;
	border-color: #5e5f60;
	border-radius: 5px;
	
}

.book form select
{
	width: 190px;
	height: 26px;
	padding-left: 5px;
	border-width:2px;
	border-radius: 5px;
	border-color: #5e5f60;
	text-align: center;	
}

.book form [type="text"]:hover,.book form [type="date"]:hover,.book form [type="email"]:hover,.book form select:hover
{
	background-color: #c2ccaf;
}
.book form [type="submit"]
{
	width: 150px;
	height: 30px;
	padding-top: 2px;
	background-color: white;
	border-color: green;
	border-radius: 15px;
	font-weight: bold;
	box-shadow: 5px 10px 30px black;
	outline: none;
}
.book form [type="submit"]:hover
{
	background-color: green;
	font-weight: bolder;
	cursor: pointer;
	box-shadow: 5px 10px 30px green;
	border-color: black;
}

.book form [type="reset"]
{
	width: 150px;
	height: 30px;
	padding-top: 2px;
	background-color: white;
	border-color: red;
	border-radius: 15px;
	font-weight: bold;
	box-shadow: 5px 10px 30px black;
	outline: none;
}
.book form [type="reset"]:hover
{
	background-color: red;
	font-weight: bolder;
	cursor: pointer;
	box-shadow: 5px 10px 30px red;
	border-color: black;
}

.heading
{
max-width: 500px;
margin: 0 auto;
background-color: skyblue;
color: black;
padding: 1px;

}

#b
{

color: yellow;
	
}
	
</style>

</head>
<body>

	
<div class="book">
	<form align="center" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
	<div class="heading">
		<h1>SELECT YOUR FAVOURITE PRODUCT NOW</h1>
	</div><br><br>
		<table align="center">
			
			
			
			
			
			
<tr>
	<td>PRODUCT TYPE:</td>
	<td>
	<?php  
echo "<select name='bnd'>";
echo '<option value="'."none".'">'."--select--".'</option>';

while ($row = $result2->fetch_assoc()) 
{

unset($btype);
$btype = $row['brand'];
echo '<option value="'.$btype.'">'.$btype.'</option>';
                 
}
echo "</select>";  

?>
</td>
			</tr>
			<tr>
				<td>QUANTITY</td>
				<td>
				<select name="qnt">
					<option id="o" value="0">---select---</option>
					<option id="o" value="1">one</option>
					<option id="o" value="2">two</option>
					<option id="o" value="3">three</option>
				</select>	
				</td>
			</tr>
			<tr></tr><tr></tr><tr></tr>
				<tr><td>PHONE NO:</td><td><input type="text" name="phone" placeholder="eg. 9876543210"></td></tr>	
				<tr><td>ADDRESS</td><td><textarea cols="25" rows="4" placeholder="Please enter address" name="address"></textarea></td></tr>
				<tr><td style="text-align: center;"><input type="submit" name="order" value="ORDER NOW"></td><td style="text-align: center;"><input type="reset" name="reset" value="RESET"></tr>
		</table><br><br>
<center><a href="logout.php">LOGOUT</a></center>
	</form>
</div>

</body>
</html>

<?php 


$conn = new mysqli('localhost', 'root', '', 'inventory') 
or die ('Cannot connect to db');

if(isset($_POST['order']))
{
	$mobile=$_POST['phone'];
	$bd=$_POST['bnd'];
	$qua=$_POST['qnt'];
	$address=$_POST['address'];
	$user=$_SESSION['user'];
	$sql = "SELECT quantity,price FROM watches where brand='$bd'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
    $totalquantity=$row['quantity'];
    $priceperunit=$row['price'];
    $totalprice=$priceperunit*$qua;
    $currentquantity=$totalquantity-$qua;
    
	 $d=date("Y/m/d");

	$sql2="INSERT INTO `orders`(`name`, `phone`, `brand`, `quantity`,`totalprice`,`dop`,`address`) VALUES ('$user',$mobile,'$bd',$qua,$totalprice,'$d','$address')";
	$sql3="update watches set quantity=$currentquantity where brand='$bd' ";
	if(mysqli_query($conn,$sql2))
	{
		if(mysqli_query($conn,$sql3))
		echo "<script> alert('updated successfully'); </script>";
		echo "<h2 id='b' align='center'>"."PLEASE PAY COD: ".$totalprice."RS/-"."</h2>";
	}
	
}
 ?>